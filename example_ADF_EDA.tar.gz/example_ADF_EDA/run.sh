#!/bin/bash 

export  SCM_TMPDIR=/home/adf/all/jorge/EDA/Li2/xprueba 

./XeO3-az.Region_1.run > XeO3-az.Region_1.out
 mv TAPE21 XeO3-az.PERRO_1.t21
./XeO3-az.Region_2.run > XeO3-az.Region_2.out
 mv TAPE21 XeO3-az.PERRO_2.t21  
./XeO3-az.run > XeO3-az.out 